The TFET_beta release version package includes:
1) tfet_beta.va
   verilog-a code;
2) /cmos_inverter_dc
   circuit test example directory;
3) modelcard.ntfet and modelcard.ptfet
   model cards for the tfet_beta.va model;
4) readme.txt
   the document you are reading.

================================================
Written by : Lining Zhang 
Oct.01,2012. 